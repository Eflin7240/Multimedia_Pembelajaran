export type FaseCard = {
  judul: string
  deskripsi: string
  checklist: string[]
}

export type SoalCek = {
  pertanyaan: string
  pilihan: string[]
  benar: number // nomor pilihan yang benar, mulai dari 0
  pembahasan: string
  xp: number
}

export type Sisi = {
  judul: string
  label: string
  butir: { judul: string; isi: string }[]
}

export type Materi = {
  judul: string
  deskripsi: string
  kd: string
  estimasiMenit: number
  video: { youtubeId: string; durasi: string; slidePdf?: string }
  intisari: { judul: string; isi: string; analogi?: { judul: string; isi: string } }
  toolsInteraktif?: ToolsInteraktif // opsional, hanya untuk modul 2 dan modul lanjutan
  perbandingan?: { judul: string; tag?: string; pengantar: string; kiri: Sisi; kanan: Sisi }
  poin: { judul: string; daftar: { judul: string; isi: string }[] }
  cek: SoalCek
}

export type ModulDetail = {
  id: string // harus sama dengan id di src/data/modul.ts, misalnya 'mod-01'
  judul: string
  deskripsi: string
  fase1: FaseCard
  fase2?: FaseCard & { label: string }
  fase3: FaseCard & { tingkat: string; kkm: number }
  peta: {
    kd: string
    poin: { judul: string; isi: string; rumus?: string }[]
  }
  materi?: Materi 
  tujuan?: Tujuan
  // boleh kosong dulu; halaman materi akan menampilkan "sedang disiapkan"
}
export type Tujuan = { sapaan: string; poin: string[]; penutup?: string }
// =============================================================
// TAMBAHAN UNTUK TOOLS INTERAKTIF (KHUSUS MODUL 2 & LANJUTAN)
// =============================================================

export type ToolItem = {
  id: string
  nama: string
  logo?: string
  deskripsi: string
  caraKerja: string[]
}

export type ToolsInteraktif = {
  judul: string
  deskripsi: string
  daftar: ToolItem[]
}